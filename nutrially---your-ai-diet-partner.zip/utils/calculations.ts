
import { UserData, Stats } from '../types';

export const calculateStats = (data: UserData): Stats => {
  const { age, gender, weight, height, activityLevel, goal } = data;

  // BMI Calculation
  const heightInMeters = height / 100;
  const bmi = weight / (heightInMeters * heightInMeters);

  let bmiCategory = '';
  if (bmi < 18.5) bmiCategory = 'Underweight';
  else if (bmi < 25) bmiCategory = 'Normal weight';
  else if (bmi < 30) bmiCategory = 'Overweight';
  else bmiCategory = 'Obese';

  // BMR Calculation (Mifflin-St Jeor Equation)
  let bmr = 10 * weight + 6.25 * height - 5 * age;
  if (gender === 'male') {
    bmr += 5;
  } else {
    bmr -= 161;
  }

  // TDEE Multipliers
  const multipliers = {
    sedentary: 1.2,
    lightly_active: 1.375,
    moderately_active: 1.55,
    very_active: 1.725,
    extra_active: 1.9,
  };

  const tdee = bmr * multipliers[activityLevel];

  // Target Calories
  let targetCalories = tdee;
  if (goal === 'lose') {
    targetCalories -= 500; // Deficit for ~0.5kg/week loss
  } else if (goal === 'gain') {
    targetCalories += 500; // Surplus for ~0.5kg/week gain
  }

  return {
    bmi: Math.round(bmi * 10) / 10,
    bmiCategory,
    bmr: Math.round(bmr),
    tdee: Math.round(tdee),
    targetCalories: Math.round(targetCalories),
  };
};
