import React, { useState } from 'react';
import { UserData, Gender, ActivityLevel, Goal, RegionalPreference } from '../types';

interface Props {
  onCalculate: (data: UserData) => void;
  isLoading: boolean;
}

const CalculatorForm: React.FC<Props> = ({ onCalculate, isLoading }) => {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState<UserData>({
    age: 25,
    gender: 'male',
    weight: 70,
    height: 175,
    activityLevel: 'moderately_active',
    goal: 'maintain',
    regionalPreference: 'Pan-Indian Fusion',
    targetWeight: 70,
    dietPreference: 'Indian Vegetarian',
    allergies: [],
    includeSupplements: true
  });

  const nextStep = () => setStep(prev => prev + 1);
  const prevStep = () => setStep(prev => prev - 1);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target as HTMLInputElement;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' 
        ? (e.target as HTMLInputElement).checked
        : (name === 'age' || name === 'weight' || name === 'height' || name === 'targetWeight' 
            ? parseFloat(value) 
            : value)
    }));
  };

  const handleAllergiesChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.split(',').map(s => s.trim()).filter(s => s !== "");
    setFormData(prev => ({ ...prev, allergies: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onCalculate(formData);
  };

  const inputClass = "w-full p-4 rounded-2xl border border-slate-200 bg-slate-50/50 focus:bg-white focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 transition-all focus:outline-none text-slate-700 font-medium placeholder:text-slate-300";
  const labelClass = "block text-xs font-black text-slate-400 uppercase tracking-widest mb-2 ml-1";

  return (
    <div className="max-w-xl mx-auto p-8 sm:p-12 bg-white rounded-[2.5rem] shadow-2xl shadow-indigo-100/50 border border-slate-100 transition-all">
      <div className="mb-10 text-center">
        <div className="flex justify-center gap-1.5 mb-6">
          {[1, 2, 3].map(i => (
            <div key={i} className={`h-1.5 rounded-full transition-all duration-500 ${step === i ? 'w-8 bg-indigo-600' : 'w-4 bg-slate-100'}`} />
          ))}
        </div>
        <h2 className="text-3xl font-black text-slate-900 tracking-tight">
          {step === 1 && "Personal Basics"}
          {step === 2 && "The Objective"}
          {step === 3 && "Dietary Style"}
        </h2>
      </div>

      <form onSubmit={handleSubmit} className="space-y-8">
        {step === 1 && (
          <div className="space-y-6 animate-in fade-in slide-in-from-right-8 duration-500">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className={labelClass}>Age</label>
                <input type="number" name="age" value={formData.age} onChange={handleChange} className={inputClass} required />
              </div>
              <div>
                <label className={labelClass}>Gender</label>
                <select name="gender" value={formData.gender} onChange={handleChange} className={inputClass}>
                  <option value="male">Male</option>
                  <option value="female">Female</option>
                </select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className={labelClass}>Weight (kg)</label>
                <input type="number" name="weight" step="0.1" value={formData.weight} onChange={handleChange} className={inputClass} required />
              </div>
              <div>
                <label className={labelClass}>Height (cm)</label>
                <input type="number" name="height" value={formData.height} onChange={handleChange} className={inputClass} required />
              </div>
            </div>
            <button 
              type="button" 
              onClick={nextStep}
              className="w-full py-4 bg-indigo-600 text-white rounded-2xl font-black text-lg hover:bg-indigo-700 transition-all shadow-xl shadow-indigo-200 active:scale-[0.98]"
            >
              Continue
            </button>
          </div>
        )}

        {step === 2 && (
          <div className="space-y-6 animate-in fade-in slide-in-from-right-8 duration-500">
            <div>
              <label className={labelClass}>How active are you?</label>
              <select name="activityLevel" value={formData.activityLevel} onChange={handleChange} className={inputClass}>
                <option value="sedentary">Sedentary (Desk Job)</option>
                <option value="lightly_active">Lightly Active (1-2 days/wk)</option>
                <option value="moderately_active">Moderately Active (3-5 days/wk)</option>
                <option value="very_active">Very Active (6-7 days/wk)</option>
                <option value="extra_active">Extra Active (Pro Athlete)</option>
              </select>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className={labelClass}>Primary Goal</label>
                <select name="goal" value={formData.goal} onChange={handleChange} className={inputClass}>
                  <option value="lose">Weight Loss</option>
                  <option value="gain">Weight Gain</option>
                  <option value="maintain">Maintenance</option>
                </select>
              </div>
              <div>
                <label className={labelClass}>Target Weight (kg)</label>
                <input type="number" name="targetWeight" step="0.1" value={formData.targetWeight} onChange={handleChange} className={inputClass} />
              </div>
            </div>
            <div className="flex gap-4">
              <button type="button" onClick={prevStep} className="flex-1 py-4 bg-slate-100 text-slate-600 rounded-2xl font-black hover:bg-slate-200 transition-all">Back</button>
              <button type="button" onClick={nextStep} className="flex-[2] py-4 bg-indigo-600 text-white rounded-2xl font-black hover:bg-indigo-700 transition-all shadow-xl shadow-indigo-200">Continue</button>
            </div>
          </div>
        )}

        {step === 3 && (
          <div className="space-y-6 animate-in fade-in slide-in-from-right-8 duration-500">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className={labelClass}>Cuisine Preference</label>
                <select name="regionalPreference" value={formData.regionalPreference} onChange={handleChange} className={inputClass}>
                  <option value="North Indian">North Indian</option>
                  <option value="South Indian">South Indian</option>
                  <option value="Pan-Indian Fusion">Pan-Indian Fusion</option>
                </select>
              </div>
              <div>
                <label className={labelClass}>Dietary Type</label>
                <select name="dietPreference" value={formData.dietPreference} onChange={handleChange} className={inputClass}>
                  <option value="Indian Vegetarian">Vegetarian</option>
                  <option value="Indian Non-Vegetarian">Non-Veg</option>
                  <option value="Eggetarian">Eggetarian</option>
                  <option value="Jain Diet">Jain</option>
                  <option value="Vegan Indian">Vegan</option>
                </select>
              </div>
            </div>
            <div>
              <label className={labelClass}>Allergies or Dislikes</label>
              <input type="text" placeholder="Gluten, Peanuts, Spicy food..." onChange={handleAllergiesChange} className={inputClass} />
            </div>
            
            <div className="flex items-center gap-3 p-4 bg-slate-50 rounded-2xl border border-slate-100">
              <input 
                type="checkbox" 
                id="includeSupplements" 
                name="includeSupplements" 
                checked={formData.includeSupplements} 
                onChange={handleChange}
                className="w-5 h-5 rounded text-indigo-600 focus:ring-indigo-500 border-slate-300" 
              />
              <label htmlFor="includeSupplements" className="text-sm font-bold text-slate-700 cursor-pointer select-none">
                Include Gym Supplements recommendations
              </label>
            </div>

            <div className="flex gap-4">
              <button type="button" onClick={prevStep} className="flex-1 py-4 bg-slate-100 text-slate-600 rounded-2xl font-black hover:bg-slate-200 transition-all">Back</button>
              <button 
                type="submit" 
                disabled={isLoading}
                className="flex-[2] py-4 bg-gradient-to-r from-indigo-600 to-violet-600 text-white rounded-2xl font-black text-lg hover:shadow-2xl hover:shadow-indigo-300 transition-all disabled:opacity-50 active:scale-[0.98]"
              >
                {isLoading ? 'Creating Plan...' : 'Generate Plan'}
              </button>
            </div>
          </div>
        )}
      </form>
    </div>
  );
};

export default CalculatorForm;