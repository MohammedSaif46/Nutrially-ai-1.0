import React, { useState, useEffect } from 'react';
import { DietPlan, Stats, DayPlan, Supplement, Meal, UserData } from '../types';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from 'recharts';
import { swapMeal, updateDietPlanWithAssistant } from '../services/gemini';

interface Props {
  plan: DietPlan | null;
  stats: Stats;
  userData: UserData;
  isGenerating: boolean;
  onReset: () => void;
}

type MealType = 'breakfast' | 'lunch' | 'dinner' | 'snack';

const PlanDisplay: React.FC<Props> = ({ plan, stats, userData, isGenerating, onReset }) => {
  const [selectedDayIndex, setSelectedDayIndex] = useState(new Date().getDay() === 0 ? 6 : new Date().getDay() - 1);
  const [localPlan, setLocalPlan] = useState<DietPlan | null>(null);
  const [editingMeal, setEditingMeal] = useState<{ dayIdx: number, type: MealType } | null>(null);
  const [editingSupplement, setEditingSupplement] = useState<number | null>(null);
  const [swappingMealType, setSwappingMealType] = useState<MealType | null>(null);
  
  // Assistant State
  const [assistantInput, setAssistantInput] = useState('');
  const [isAssistantLoading, setIsAssistantLoading] = useState(false);
  const [assistantMessage, setAssistantMessage] = useState<string | null>(null);

  // Reminder State
  const [remindersEnabled, setRemindersEnabled] = useState(false);
  const [permissionStatus, setPermissionStatus] = useState<NotificationPermission>('default');

  useEffect(() => {
    if (plan) {
      setLocalPlan(JSON.parse(JSON.stringify(plan)));
    }
  }, [plan]);

  useEffect(() => {
    if ("Notification" in window) {
      setPermissionStatus(Notification.permission);
    }
  }, []);

  // Simple logic to check for meal times every minute
  useEffect(() => {
    if (!remindersEnabled || !localPlan) return;

    const mealTimes = {
      '08:30': 'breakfast',
      '13:30': 'lunch',
      '16:30': 'snack',
      '20:30': 'dinner'
    };

    const checkMealTime = () => {
      const now = new Date();
      const timeStr = now.toTimeString().substring(0, 5); // "HH:MM"
      
      if (mealTimes[timeStr as keyof typeof mealTimes]) {
        const type = mealTimes[timeStr as keyof typeof mealTimes] as MealType;
        const todayIdx = now.getDay() === 0 ? 6 : now.getDay() - 1;
        const meal = localPlan.weeklyPlan[todayIdx][type];
        
        sendNotification(
          `Time for ${type.charAt(0).toUpperCase() + type.slice(1)}! 🥗`,
          `Today's Goal: ${meal.name} (${meal.calories} kcal). Stay on track!`
        );
      }
    };

    const interval = setInterval(checkMealTime, 60000); // Check every minute
    return () => clearInterval(interval);
  }, [remindersEnabled, localPlan]);

  const sendNotification = (title: string, body: string) => {
    if (Notification.permission === 'granted') {
      new Notification(title, {
        body,
        icon: 'https://cdn-icons-png.flaticon.com/512/3034/3034833.png'
      });
    }
  };

  const handleToggleReminders = async () => {
    if (!("Notification" in window)) {
      alert("This browser does not support desktop notifications");
      return;
    }

    if (Notification.permission !== 'granted') {
      const permission = await Notification.requestPermission();
      setPermissionStatus(permission);
      if (permission === 'granted') {
        setRemindersEnabled(true);
        sendNotification("Reminders Active! 🔔", "NutriAlly will now alert you at meal times.");
      }
    } else {
      setRemindersEnabled(!remindersEnabled);
    }
  };

  const currentDay = localPlan?.weeklyPlan[selectedDayIndex];

  const macroData = localPlan ? [
    { name: 'Protein', value: localPlan.overview.macronutrientRatio.protein, color: '#4f46e5' },
    { name: 'Carbs', value: localPlan.overview.macronutrientRatio.carbs, color: '#6366f1' },
    { name: 'Fats', value: localPlan.overview.macronutrientRatio.fats, color: '#94a3b8' },
  ] : [];

  const handleEditMeal = (type: MealType) => {
    setEditingMeal({ dayIdx: selectedDayIndex, type });
  };

  const handleSaveMeal = (updatedMeal: Meal) => {
    if (!localPlan) return;
    const newPlan = { ...localPlan };
    newPlan.weeklyPlan[selectedDayIndex][editingMeal!.type] = updatedMeal;
    const day = newPlan.weeklyPlan[selectedDayIndex];
    day.totalCalories = day.breakfast.calories + day.lunch.calories + day.dinner.calories + day.snack.calories;
    setLocalPlan(newPlan);
    setEditingMeal(null);
  };

  const handleSwapMeal = async (type: MealType, current: Meal) => {
    if (!localPlan) return;
    setSwappingMealType(type);
    try {
      const alternative = await swapMeal(current, current.calories, userData);
      const newPlan = { ...localPlan };
      newPlan.weeklyPlan[selectedDayIndex][type] = alternative;
      setLocalPlan(newPlan);
    } catch (err) {
      console.error("Failed to swap meal:", err);
    } finally {
      setSwappingMealType(null);
    }
  };

  const handleAssistantSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!localPlan || !assistantInput.trim()) return;

    setIsAssistantLoading(true);
    setAssistantMessage(null);
    try {
      const updatedPlan = await updateDietPlanWithAssistant(localPlan, assistantInput, userData);
      setLocalPlan(updatedPlan);
      setAssistantInput('');
      setAssistantMessage('Plan updated successfully! ✨');
      setTimeout(() => setAssistantMessage(null), 3000);
    } catch (err) {
      console.error("Assistant Error:", err);
      setAssistantMessage('Failed to update. Please be more specific.');
    } finally {
      setIsAssistantLoading(false);
    }
  };

  const handleSaveSupplement = (idx: number, updated: Supplement) => {
    if (!localPlan) return;
    const newPlan = { ...localPlan };
    newPlan.overview.supplements[idx] = updated;
    setLocalPlan(newPlan);
    setEditingSupplement(null);
  };

  return (
    <div className="space-y-8 pb-32 relative">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h2 className="text-3xl font-black text-slate-900 tracking-tight">Metabolic Dashboard</h2>
          <p className="text-slate-500 font-medium">{userData.regionalPreference} Protocol • {userData.dietPreference}</p>
        </div>
        <button 
          onClick={onReset}
          className="w-fit px-5 py-2.5 bg-white border border-slate-200 text-slate-600 rounded-xl font-bold transition-all hover:bg-slate-50 hover:shadow-md active:scale-95 flex items-center gap-2"
        >
          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" /></svg>
          Reset Profile
        </button>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: 'BMI', value: stats.bmi, sub: stats.bmiCategory },
          { label: 'TDEE', value: stats.tdee, sub: 'Maintenance' },
          { label: 'Target', value: stats.targetCalories, sub: 'Daily Intake', primary: true },
          { label: 'BMR', value: stats.bmr, sub: 'Basal Rate' },
        ].map((item, i) => (
          <div key={i} className={`p-6 rounded-3xl shadow-sm border transition-all hover:shadow-md ${item.primary ? 'bg-indigo-600 text-white border-indigo-500 shadow-indigo-100' : 'bg-white text-slate-800 border-slate-100'}`}>
            <p className={`text-xs font-black uppercase tracking-widest mb-1 ${item.primary ? 'text-indigo-100' : 'text-slate-400'}`}>{item.label}</p>
            <h3 className="text-3xl font-black mb-1">{item.value}</h3>
            <p className={`text-[10px] font-bold uppercase ${item.primary ? 'text-indigo-200' : 'text-indigo-600'}`}>{item.sub}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        <div className="lg:col-span-4 space-y-6">
          {/* Reminders Card */}
          <div className="bg-white p-6 rounded-[2rem] shadow-sm border border-slate-100">
            <h4 className="text-lg font-black text-slate-900 mb-4 flex items-center gap-2">
              <svg className="w-5 h-5 text-indigo-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" /></svg>
              Reminders
            </h4>
            <div className="space-y-4">
              <div className="flex items-center justify-between p-3 bg-slate-50 rounded-2xl">
                <div>
                  <p className="text-sm font-black text-slate-800">Meal Alerts</p>
                  <p className="text-[10px] text-slate-500 font-bold uppercase tracking-tight">Daily Meal Check-ins</p>
                </div>
                <button 
                  onClick={handleToggleReminders}
                  className={`w-12 h-6 rounded-full transition-all relative ${remindersEnabled ? 'bg-indigo-600' : 'bg-slate-300'}`}
                >
                  <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${remindersEnabled ? 'left-7' : 'left-1'}`} />
                </button>
              </div>
              {remindersEnabled && (
                <button 
                  onClick={() => sendNotification("Test Alert 🍎", "This is how your meal reminders will look!")}
                  className="w-full py-2 border-2 border-dashed border-slate-200 rounded-xl text-[10px] font-black text-slate-400 uppercase tracking-widest hover:border-indigo-300 hover:text-indigo-600 transition-all"
                >
                  Send Test Alert
                </button>
              )}
            </div>
          </div>

          <div className="bg-white p-6 rounded-[2rem] shadow-sm border border-slate-100">
            <h4 className="text-lg font-black text-slate-900 mb-4 flex items-center justify-between">
              Timeline
              <span className="text-[10px] bg-slate-100 text-slate-500 px-2 py-0.5 rounded-full uppercase tracking-widest">7 Days</span>
            </h4>
            {localPlan ? (
              <div className="grid grid-cols-4 gap-2">
                {localPlan.weeklyPlan.map((day, idx) => (
                  <button
                    key={idx}
                    onClick={() => { setSelectedDayIndex(idx); setEditingMeal(null); }}
                    className={`aspect-square flex items-center justify-center rounded-xl text-xs font-black transition-all ${selectedDayIndex === idx ? 'bg-indigo-600 text-white shadow-lg' : 'bg-slate-50 text-slate-400 hover:bg-slate-100'}`}
                  >
                    {day.day.substring(0, 3)}
                  </button>
                ))}
              </div>
            ) : <div className="h-20 bg-slate-50 rounded-2xl animate-pulse"></div>}
          </div>

          {localPlan && localPlan.overview.supplements.length > 0 && (
            <div className="bg-gradient-to-br from-slate-900 to-slate-800 p-6 rounded-[2rem] shadow-xl text-white">
              <h4 className="text-lg font-black mb-4 flex items-center gap-2">Supplement Stack</h4>
              <div className="space-y-4">
                {localPlan.overview.supplements.map((supp, i) => (
                  <div key={i} className="group border-l-2 border-indigo-500/50 pl-4 py-1 relative">
                    {editingSupplement === i ? (
                      <div className="space-y-2">
                        <input className="w-full bg-slate-700 text-xs p-1.5 rounded" value={supp.name} onChange={e => handleSaveSupplement(i, {...supp, name: e.target.value})} />
                        <input className="w-full bg-slate-700 text-[10px] p-1.5 rounded" value={supp.dosage} onChange={e => handleSaveSupplement(i, {...supp, dosage: e.target.value})} />
                        <button onClick={() => setEditingSupplement(null)} className="text-[9px] font-black uppercase text-indigo-400">Done</button>
                      </div>
                    ) : (
                      <>
                        <div className="flex justify-between items-start">
                          <p className="font-black text-indigo-300 text-sm">{supp.name}</p>
                          <button onClick={() => setEditingSupplement(i)} className="opacity-0 group-hover:opacity-100 text-[9px] text-slate-500 uppercase font-black">Edit</button>
                        </div>
                        <p className="text-[11px] text-slate-300 font-medium">{supp.dosage} • {supp.timing}</p>
                        <p className="text-[10px] text-slate-400 italic mt-1">{supp.benefit}</p>
                      </>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="bg-white p-6 rounded-[2rem] shadow-sm border border-slate-100 h-64">
             <h4 className="text-lg font-black text-slate-900 mb-2">Macro Ratio</h4>
             <ResponsiveContainer width="100%" height="90%">
                <PieChart>
                  <Pie data={macroData} cx="50%" cy="50%" innerRadius={45} outerRadius={65} paddingAngle={8} dataKey="value">
                    {macroData.map((entry, index) => <Cell key={`cell-${index}`} fill={entry.color} />)}
                  </Pie>
                  <Tooltip contentStyle={{ borderRadius: '1rem', border: 'none' }} />
                  <Legend verticalAlign="bottom" height={36} iconType="circle" wrapperStyle={{ fontSize: '11px', fontWeight: 'bold' }} />
                </PieChart>
             </ResponsiveContainer>
          </div>
        </div>

        <div className="lg:col-span-8 space-y-4">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-2xl font-black text-slate-900">{currentDay?.day} Protocol</h3>
            {currentDay && <span className="px-4 py-1.5 bg-indigo-50 text-indigo-700 rounded-full text-xs font-black uppercase">{currentDay.totalCalories} Daily kcal</span>}
          </div>

          {localPlan && currentDay ? (
            ([
              { type: 'breakfast' as MealType, meal: currentDay.breakfast, color: 'indigo', label: 'Breakfast' },
              { type: 'lunch' as MealType, meal: currentDay.lunch, color: 'blue', label: 'Lunch' },
              { type: 'snack' as MealType, meal: currentDay.snack, color: 'slate', label: 'Snack' },
              { type: 'dinner' as MealType, meal: currentDay.dinner, color: 'violet', label: 'Dinner' },
            ]).map((item, idx) => (
              <div key={idx} className="bg-white p-6 rounded-[2rem] shadow-sm border border-slate-100 hover:border-indigo-200 transition-all group relative">
                {swappingMealType === item.type && (
                  <div className="absolute inset-0 bg-white/80 backdrop-blur-sm z-10 rounded-[2rem] flex items-center justify-center">
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 border-2 border-indigo-600 border-t-transparent rounded-full animate-spin"></div>
                      <span className="text-xs font-black text-indigo-600 uppercase tracking-widest">Finding Alternative...</span>
                    </div>
                  </div>
                )}
                {editingMeal?.type === item.type ? (
                   <MealEditor meal={item.meal} onSave={handleSaveMeal} onCancel={() => setEditingMeal(null)} color={item.color} />
                ) : (
                  <>
                    <div className="flex flex-col sm:flex-row justify-between items-start gap-4 mb-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-3">
                          <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest bg-${item.color}-50 text-${item.color}-600 border border-${item.color}-100`}>{item.label}</span>
                          <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                            <button onClick={() => handleEditMeal(item.type)} className="p-1.5 rounded-lg text-slate-300 hover:text-indigo-600 hover:bg-slate-50" title="Edit Meal">
                              <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" /></svg>
                            </button>
                            <button onClick={() => handleSwapMeal(item.type, item.meal)} className="p-1.5 rounded-lg text-slate-300 hover:text-emerald-600 hover:bg-slate-50" title="Swap for Alternative">
                              <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" /></svg>
                            </button>
                          </div>
                        </div>
                        <h4 className="text-xl font-black text-slate-800 group-hover:text-indigo-600 transition-colors">{item.meal.name}</h4>
                        <p className="text-slate-500 text-sm mt-1 leading-relaxed">{item.meal.description}</p>
                      </div>
                      <div className="flex sm:flex-col items-center sm:items-end gap-2 sm:gap-0">
                        <span className="text-2xl font-black text-slate-900">{item.meal.calories}</span>
                        <p className="text-[10px] text-slate-400 font-black uppercase">kcal</p>
                      </div>
                    </div>
                    <div className="grid grid-cols-3 gap-3 border-t border-slate-50 pt-5 mb-4">
                      {[{l:'Protein',v:item.meal.protein,c:'indigo'},{l:'Carbs',v:item.meal.carbs,c:'blue'},{l:'Fats',v:item.meal.fats,c:'slate'}].map((macro, i) => (
                        <div key={i} className="bg-slate-50/50 rounded-2xl py-3 text-center border border-slate-50">
                          <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">{macro.l}</p>
                          <p className={`font-black text-lg text-${macro.c}-600`}>{macro.v}<span className="text-[10px] ml-0.5">g</span></p>
                        </div>
                      ))}
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {item.meal.ingredients.map((ing, i) => <span key={i} className="text-[11px] font-bold bg-white text-slate-500 px-3 py-1.5 rounded-xl border border-slate-100 shadow-sm">{ing}</span>)}
                    </div>
                  </>
                )}
              </div>
            ))
          ) : <div className="h-96 bg-slate-50 rounded-[2.5rem] animate-pulse"></div>}
        </div>
      </div>

      {/* AI Diet Assistant Footer */}
      <div className="fixed bottom-0 left-0 right-0 p-4 md:p-6 bg-gradient-to-t from-slate-50 via-slate-50/90 to-transparent no-print pointer-events-none">
        <div className="max-w-4xl mx-auto pointer-events-auto">
          <form 
            onSubmit={handleAssistantSubmit}
            className={`flex items-center gap-3 p-2 bg-white rounded-full shadow-2xl border transition-all duration-300 ${isAssistantLoading ? 'border-indigo-500 ring-4 ring-indigo-500/10' : 'border-slate-200'}`}
          >
            <div className={`p-3 rounded-full ${isAssistantLoading ? 'bg-indigo-600 text-white animate-pulse' : 'bg-indigo-50 text-indigo-600'}`}>
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M13 10V3L4 14h7v7l9-11h-7z" />
              </svg>
            </div>
            <input 
              type="text"
              placeholder={isAssistantLoading ? "Refining your protocol..." : "Tell assistant to add/remove foods or change style..."}
              className="flex-1 bg-transparent border-none focus:ring-0 text-sm font-medium text-slate-700 placeholder:text-slate-400 px-2"
              value={assistantInput}
              onChange={(e) => setAssistantInput(e.target.value)}
              disabled={isAssistantLoading}
            />
            {assistantMessage && (
              <span className="hidden md:inline text-[10px] font-black uppercase text-emerald-600 tracking-widest mr-2 animate-bounce">
                {assistantMessage}
              </span>
            )}
            <button 
              type="submit"
              disabled={isAssistantLoading || !assistantInput.trim()}
              className="px-6 py-2.5 bg-indigo-600 text-white rounded-full text-xs font-black uppercase tracking-wider hover:bg-indigo-700 transition-all disabled:opacity-50"
            >
              {isAssistantLoading ? '...' : 'Apply'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

const MealEditor: React.FC<{ meal: Meal, onSave: (m: Meal) => void, onCancel: () => void, color: string }> = ({ meal, onSave, onCancel, color }) => {
  const [formData, setFormData] = useState<Meal>({ ...meal });
  const inputClass = "w-full p-2.5 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 transition-all text-xs font-bold text-slate-700";
  const labelClass = "block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1";
  return (
    <div className="space-y-4 animate-in fade-in duration-300">
      <div className="flex justify-between items-center border-b border-slate-100 pb-3 mb-2">
        <h5 className="font-black text-indigo-600 text-sm uppercase tracking-wider">Customize Meal</h5>
        <div className="flex gap-2">
          <button onClick={onCancel} className="px-3 py-1.5 bg-slate-100 text-slate-500 rounded-lg text-[10px] font-black uppercase">Cancel</button>
          <button onClick={() => onSave(formData)} className="px-3 py-1.5 bg-indigo-600 text-white rounded-lg text-[10px] font-black uppercase">Save</button>
        </div>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label className={labelClass}>Meal Name</label>
          <input className={inputClass} value={formData.name} onChange={e => setFormData({ ...formData, name: e.target.value })} />
        </div>
        <div>
          <label className={labelClass}>Calories (kcal)</label>
          <input type="number" className={inputClass} value={formData.calories} onChange={e => setFormData({ ...formData, calories: parseInt(e.target.value) || 0 })} />
        </div>
      </div>
      <div>
        <label className={labelClass}>Ingredients (comma separated)</label>
        <input className={inputClass} value={formData.ingredients.join(', ')} onChange={e => setFormData({ ...formData, ingredients: e.target.value.split(',').map(s => s.trim()) })} />
      </div>
      <div className="grid grid-cols-3 gap-3">
        {['protein', 'carbs', 'fats'].map((m) => (
          <div key={m}>
            <label className={labelClass}>{m.charAt(0).toUpperCase() + m.slice(1)} (g)</label>
            <input type="number" className={inputClass} value={(formData as any)[m]} onChange={e => setFormData({ ...formData, [m]: parseInt(e.target.value) || 0 })} />
          </div>
        ))}
      </div>
    </div>
  );
};

export default PlanDisplay;