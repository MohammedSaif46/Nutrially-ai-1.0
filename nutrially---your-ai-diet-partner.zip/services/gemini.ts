import { GoogleGenAI, Type } from "@google/genai";
import { UserData, DietPlan, Stats, Meal } from "../types";

const MEAL_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    name: { type: Type.STRING, description: "Name of the dish" },
    description: { type: Type.STRING, description: "Short description of the meal" },
    calories: { type: Type.NUMBER, description: "Calories in kcal" },
    protein: { type: Type.NUMBER, description: "Protein in grams" },
    carbs: { type: Type.NUMBER, description: "Carbohydrates in grams" },
    fats: { type: Type.NUMBER, description: "Fats in grams" },
    ingredients: { type: Type.ARRAY, items: { type: Type.STRING }, description: "List of main ingredients" }
  },
  required: ["name", "description", "calories", "protein", "carbs", "fats", "ingredients"]
};

const PLAN_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    weeklyPlan: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          day: { type: Type.STRING },
          breakfast: MEAL_SCHEMA,
          lunch: MEAL_SCHEMA,
          dinner: MEAL_SCHEMA,
          snack: MEAL_SCHEMA,
          totalCalories: { type: Type.NUMBER }
        },
        required: ["day", "breakfast", "lunch", "dinner", "snack", "totalCalories"]
      }
    },
    overview: {
      type: Type.OBJECT,
      properties: {
        dailyCalorieTarget: { type: Type.NUMBER },
        macronutrientRatio: {
          type: Type.OBJECT,
          properties: {
            protein: { type: Type.NUMBER },
            carbs: { type: Type.NUMBER },
            fats: { type: Type.NUMBER }
          },
          required: ["protein", "carbs", "fats"]
        },
        advice: { type: Type.STRING },
        supplements: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              name: { type: Type.STRING },
              dosage: { type: Type.STRING },
              timing: { type: Type.STRING },
              benefit: { type: Type.STRING }
            },
            required: ["name", "dosage", "timing", "benefit"]
          }
        }
      },
      required: ["dailyCalorieTarget", "macronutrientRatio", "advice", "supplements"]
    }
  },
  required: ["weeklyPlan", "overview"]
};

export const generateDietPlan = async (userData: UserData, stats: Stats): Promise<DietPlan> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const supplementInstructions = userData.includeSupplements 
    ? `3. Suggest 2-4 Gym Supplements tailored to their ${userData.goal} goal. Include precise dosage and Indian-context benefits.`
    : `3. DO NOT suggest any supplements. Return an empty array.`;

  const regionalContext = userData.regionalPreference === 'North Indian' 
    ? "Focus on North Indian cuisine: Parathas, Paneer, Dals, Chole, Kebabs."
    : userData.regionalPreference === 'South Indian'
    ? "Focus on South Indian cuisine: Dosa, Idli, Sambar, Rasam, coconut-based curries."
    : "Mix both North and South Indian cuisines.";

  const prompt = `
    Role: NutriAlly Expert Nutritionist. Create a 7-Day Indian Diet Plan.
    User: ${userData.age}y/o ${userData.gender}, ${userData.weight}kg, Goal: ${userData.goal}.
    Target: ${stats.targetCalories} kcal/day.
    Region: ${userData.regionalPreference}. ${regionalContext}
    Diet: ${userData.dietPreference}. Allergies: ${userData.allergies.join(', ') || 'None'}.
    Output JSON only matching the schema.
  `;

  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: prompt,
    config: {
      temperature: 0.2,
      responseMimeType: "application/json",
      responseSchema: PLAN_SCHEMA as any
    }
  });

  if (!response.text) throw new Error("Connection lost.");
  return JSON.parse(response.text) as DietPlan;
};

export const swapMeal = async (currentMeal: Meal, targetCalories: number, userData: UserData): Promise<Meal> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const prompt = `
    Suggest ONE alternative Indian meal for ${userData.regionalPreference} preference.
    Must be ${userData.dietPreference} and around ${targetCalories} calories.
    Previous meal: "${currentMeal.name}". Provide a different authentic dish.
    Output JSON only.
  `;

  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: prompt,
    config: {
      temperature: 0.7,
      responseMimeType: "application/json",
      responseSchema: MEAL_SCHEMA as any
    }
  });

  return JSON.parse(response.text || '{}') as Meal;
};

export const updateDietPlanWithAssistant = async (currentPlan: DietPlan, instruction: string, userData: UserData): Promise<DietPlan> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const prompt = `
    You are the NutriAlly Assistant. Modify the current 7-day diet plan based on the user's request.
    Current Plan: ${JSON.stringify(currentPlan)}
    User Request: "${instruction}"
    Rules:
    1. Maintain the daily calorie target of ${currentPlan.overview.dailyCalorieTarget} kcal.
    2. Respect the original ${userData.dietPreference} and regional preferences unless the user asks to change them.
    3. Update ingredients, meal names, or whole dishes as requested.
    4. If they ask to "remove" something, ensure it is gone from all 7 days.
    5. Output the full 7-day plan in JSON matching the original schema.
  `;

  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: prompt,
    config: {
      temperature: 0.3,
      responseMimeType: "application/json",
      responseSchema: PLAN_SCHEMA as any
    }
  });

  if (!response.text) throw new Error("Assistant failed to process request.");
  return JSON.parse(response.text) as DietPlan;
};